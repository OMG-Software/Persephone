"""Query OSV for public registry packages in the two research lockfiles."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import tomllib
from urllib.request import Request, urlopen

BASE = Path(__file__).resolve().parent
PROBES = BASE / "probes"
OUTPUT = BASE / "advisory-check.json"


def request(url, payload=None):
    encoded = json.dumps(payload).encode() if payload is not None else None
    headers = {"User-Agent": "Persephone-security-research", "Content-Type": "application/json"}
    with urlopen(Request(url, data=encoded, headers=headers), timeout=60) as response:
        return json.load(response)


framework_packages = {}
active = {}
for framework in ["slint", "iced"]:
    lock = tomllib.loads((PROBES / framework / "Cargo.lock").read_text())
    framework_packages[framework] = {
        (p["name"], p["version"])
        for p in lock["package"]
        if p.get("source", "").startswith("registry+")
    }
    active[framework] = {}
    for graph in (PROBES / framework).glob("tree-*.txt"):
        active[framework][graph.stem.removeprefix("tree-")] = set(
            re.findall(r"([A-Za-z0-9_-]+) v([0-9][0-9A-Za-z.+-]*)", graph.read_text(encoding="utf-8-sig"))
        )

packages = sorted(set.union(*framework_packages.values()))
queries = [{"package": {"name": name, "ecosystem": "crates.io"}, "version": version} for name, version in packages]
response = request("https://api.osv.dev/v1/querybatch", {"queries": queries})
results = response["results"]
assert len(results) == len(packages), "Incomplete OSV batch response"
ids = sorted({v["id"] for result in results for v in result.get("vulns", [])})
with ThreadPoolExecutor(max_workers=6) as pool:
    details = dict(zip(ids, pool.map(lambda identifier: request(f"https://api.osv.dev/v1/vulns/{identifier}"), ids)))

findings = []
for package, result in zip(packages, results):
    for vulnerability in result.get("vulns", []):
        identifier = vulnerability["id"]
        detail = details[identifier]
        findings.append({
            "package": package[0], "version": package[1], "id": identifier,
            "summary": detail.get("summary"), "withdrawn": detail.get("withdrawn"),
            "frameworks": [f for f, locked in framework_packages.items() if package in locked],
            "normal_graph_targets": {f: [t for t, graph in targets.items() if package in graph] for f, targets in active.items()},
        })

output = {
    "queried_at_utc": datetime.now(timezone.utc).isoformat(),
    "method": "OSV version queries for public crates in fresh research locks; not cargo-audit or runtime exploit testing",
    "packages_queried": len(packages),
    "lockfile_public_package_counts": {f: len(p) for f, p in framework_packages.items()},
    "queries": queries, "raw_response": response, "details": details, "findings": findings,
}
OUTPUT.write_text(json.dumps(output, indent=2), encoding="utf-8")
print(json.dumps({k: output[k] for k in ["queried_at_utc", "packages_queried", "lockfile_public_package_counts", "findings"]}, indent=2))
