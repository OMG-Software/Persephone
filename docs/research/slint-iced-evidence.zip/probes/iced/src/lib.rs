// Dependency-resolution probe only. No application implementation.
