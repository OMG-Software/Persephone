"""Capture public upstream evidence; does not build or run upstream code."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

BASE = Path(__file__).resolve().parent
OUT = BASE / "evidence"
OUT.mkdir(parents=True, exist_ok=True)
HEADERS = {"User-Agent": "Persephone-security-research", "Accept": "application/vnd.github+json"}


def fetch(url):
    with urlopen(Request(url, headers=HEADERS), timeout=45) as response:
        return response.read()


def capture(item):
    name, url = item
    try:
        data = fetch(url)
        destination = OUT / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        return {"file": name, "url": url, "sha256": sha256(data).hexdigest(), "bytes": len(data), "status": 200}
    except HTTPError as error:
        return {"file": name, "url": url, "status": error.code}
    except Exception as error:
        return {"file": name, "url": url, "error": str(error)}


repositories = {"slint": "slint-ui/slint", "iced": "iced-rs/iced"}
snapshots = {}
jobs = []
for label, repository in repositories.items():
    api = f"https://api.github.com/repos/{repository}"
    release = json.loads(fetch(f"{api}/releases/latest"))
    tag = release["tag_name"]
    commit = json.loads(fetch(f"{api}/commits/{tag}"))["sha"]
    snapshots[label] = {"repository": repository, "tag": tag, "commit": commit, "published_at": release["published_at"], "release_url": release["html_url"]}
    (OUT / f"{label}-release.json").write_text(json.dumps(release, indent=2), encoding="utf-8")
    jobs.extend([(f"{label}/tree.json", f"{api}/git/trees/{commit}?recursive=1"), (f"{label}/advisories.json", f"{api}/security-advisories")])

paths = {
    "slint": ["Cargo.toml", "Cargo.lock", "SECURITY.md", "api/rs/slint/Cargo.toml", "internal/backends/selector/Cargo.toml", "internal/backends/winit/Cargo.toml", "internal/renderers/skia/Cargo.toml", "internal/renderers/software/Cargo.toml", "internal/core/Cargo.toml", "internal/core/graphics/image.rs", "api/rs/slint/lib.rs"],
    "iced": ["Cargo.toml", "Cargo.lock", "SECURITY.md", "DEPENDENCIES.md", "README.md", "renderer/Cargo.toml", "graphics/Cargo.toml", "winit/Cargo.toml", "tiny_skia/Cargo.toml", "wgpu/Cargo.toml", "core/src/image.rs", "core/src/svg.rs", "graphics/src/image.rs", "widget/Cargo.toml", "widget/src/markdown.rs"],
}
for label, source_paths in paths.items():
    snapshot = snapshots[label]
    for path in source_paths:
        jobs.append((f"{label}/{path}", f"https://raw.githubusercontent.com/{snapshot['repository']}/{snapshot['commit']}/{path}"))

with ThreadPoolExecutor(max_workers=8) as executor:
    records = list(executor.map(capture, jobs))
manifest = {"captured_at_utc": datetime.now(timezone.utc).isoformat(), "snapshots": snapshots, "records": records}
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps({"snapshots": snapshots, "successful_files": sum(item.get("status") == 200 for item in records), "failures": [item for item in records if item.get("status") != 200]}, indent=2))
